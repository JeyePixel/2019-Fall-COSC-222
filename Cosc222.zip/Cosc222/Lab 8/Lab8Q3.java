package lab8;

import java.io.*; 
import java.util.*; 

class GraphTraversalDFS{
  private int V;                         // No. of vertices 
  private LinkedList<Integer> adj[];     //To store a adjacency list
  
  /* 
   * Initialize a graph 
   */
  GraphTraversalDFS(int v) { 
	  V = v;
	  adj = new LinkedList[V];
		 
	  //  Prepare adjListArray to hold multiple LinkedLists
	  for (int i = 0; i < V; i++) {
			 adj[i] = new LinkedList<Integer>();
	  }
  } 
  
  /* 
   * Add an edge into a graph 
   */
  void addEdge(int v, int w) 
  { 
    adj[v].add(w);
  } 
  
  /* 
  * Method to traverse the graph with DFS
  * Suggestion: write recursive DFS
  */
  void DFS(int v,boolean visited[]) 
  { 
	  visited[v] = true;
	  for (int neighbor : adj[v]) {
		  if (!visited[neighbor]) {
			  DFS(neighbor, visited);
		  }
	  }
  } 
  
  /* 
  * Method to calculate the number of starting nodes 
  */
  void countStartingNodes() 
  { 
    boolean[] visited = new boolean[V];
    ArrayList startingNodes = new ArrayList();
    int count = 0;
    for(int i=0; i < visited.length; i++) {
    	if (!visited[i]) {
    		DFS(i, visited);
    		count++;
    		startingNodes.add(i);
    	}
    }
    System.out.println("You can traverse the entire graph by selecting " + count + " starting vertices.");
	System.out.println("Starting vertices are " + startingNodes.toString());
  } 
}

/* 
 * This class is to read the inputQ3.txt text file.
 * This class also calls the GraphTraversalDFS class
 * to calculate the number of starting vertices
 */
public class Lab8Q3{ 
  public static void main(String args[]) {
    
	File file = new File("C:\\Users\\iheal\\eclipse-workspace\\COSC222\\src\\lab8\\inputQ3.txt");                          //File path
    Scanner scan;
    try {
      scan = new Scanner(file);
      int nodes = scan.nextInt();
      GraphTraversalDFS graph = new GraphTraversalDFS(nodes);     //Initialize a graph
      
      for (int i = 0; i < nodes; i++)                             //For loop to read the text file
        for (int j = 0; j < nodes; j++)
        if (scan.nextInt() == 1)
        graph.addEdge(i, j);
      
      graph.countStartingNodes();                                  //To show the number of starting vertices 
      scan.close();
      
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }
}