package lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.LinkedList;
import java.util.Scanner;

class Graph{
 
 int N;                                // No. of vertices 
 LinkedList<Integer> adjListArray[];   //To store a adjacency list

 @SuppressWarnings("unchecked")
//Initialize a graph
 Graph(int nodes) {
	 //  All we need to do at this point is initialize the number of vertices  and the LinkedList
	 N = nodes;
	 adjListArray = new LinkedList[N];
	 
	 //  Prepare adjListArray to hold multiple LinkedLists
	 for (int i = 0; i < N; i++) {
		 adjListArray[i] = new LinkedList<Integer>();
	 }
 }
 
 // Adds an edge from a source vertex to a destination vertex
 void addEdge(int src, int dest) {
	 adjListArray[src].add(dest);
 }

 // A method to print the adjacency list 
 @SuppressWarnings("null")
void printGraph(Graph graph) {
	 StringBuilder result = new StringBuilder();
	 for (int col = 0; col < N; col ++) {
		 result.append("Adjacency list of vertex " + col + ": ");
		 
		 //  Check if a LinkedList has any edges whatsoever
		 if (adjListArray[col].size() > 0) {
			 for (int row = 0; row < adjListArray[col].size(); row++) {
				 result.append(adjListArray[col].get(row) + " ");
			 }
		 } else {
			 result.append("No vertex found");
		 }
		 result.append("\n");
	 }
	 System.out.println(result.toString());
	 }
}

/* 
* This class is to read the inputQ1.txt text file.
* This class also calls the Graph class
* to show the adjacency list 
*/

public class Lab8Q1 {

 public static void main(String args[]) {
  
  //Copy the input files in the project directory.
  // your project directory may look like C:\Users\YourUserName\eclipse-workspace\YourProjectName.
  File file = new File("C:\\Users\\iheal\\eclipse-workspace\\COSC222\\src\\lab8\\inputQ1.txt");  //File path
  //System.out.println("File path is: " + file.getAbsolutePath());
  Scanner scan;
  
  try {
   scan = new Scanner(file);
   int nodes = scan.nextInt();
   Graph graph = new Graph(nodes);         //Initialize a graph

   for (int i = 0; i < nodes; i++)         //For loops to read the adjacency matrix stored in a text file
    for (int j = 0; j < nodes; j++)
     if (scan.nextInt() == 1)
      graph.addEdge(i, j);                
   
   graph.printGraph(graph);                 //To show the graph
   scan.close();
  } catch (FileNotFoundException e) {
   e.printStackTrace();
  }
  
 }
}