package lab8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

class GraphTraversal{
 private int V;                      // No. of vertices
 private LinkedList<Integer> adj[];  //To store a adjacency list

/* 
* Initialize a graph 
*/
 GraphTraversal(int v) {
	 V = v;
	 adj = new LinkedList[V+1];
	 
	 for (int i = 0; i <= V; i++) {
		 adj[i] = new LinkedList<Integer>();
	 }
 }

/* 
* Add an edge into a graph 
*/
void addEdge(int v, int w) {
	adj[v].add(w);
 }

/* 
* This method is to calculate and show the shortest path from a given vertex
*/
 void shortestPath(int start) {
	 boolean[] visited = new boolean[V];
	 Queue<Integer> nodesToVisit = new LinkedList<>();
	 
	 int distance = 0;
	 
	 nodesToVisit.add(start);
	 nodesToVisit.add(distance);
	 
	 String result = null;
	 Integer currentNode = null;
	 visited[start] = true;
	 while(!nodesToVisit.isEmpty()) {
		 currentNode = nodesToVisit.remove();
		 distance = nodesToVisit.remove();
		 
		 
		 result = "The distance from vertex " + start + " to vertex " + currentNode + " is: " + distance;
		 
		 distance++;

		 System.out.println(result);
		 
		 for (int i : adj[currentNode]) {
			 if (!visited[i]) {
				 nodesToVisit.add(i);
				 nodesToVisit.add(distance);
			 }
		 }
	 }
 }
}


/* 
* This class is to read the inputQ2.txt text file.
* This class also calls the GraphTraversal class
* to find the distance from a vertex to all other
* vertices
*/
public class Lab8Q2 {
 
 public static void main(String args[]) {
	 File file = new File("C:\\Users\\iheal\\eclipse-workspace\\COSC222\\src\\lab8\\inputQ2.txt");  //File path
	 Scanner scan;
	 try {
		 scan = new Scanner(file);

	int nodes = scan.nextInt();
    int edges = scan.nextInt();
    
    GraphTraversal graph = new GraphTraversal(nodes);        //Initialize a graph

    for (int i = 0; i < edges; i++)
    graph.addEdge(scan.nextInt(), scan.nextInt());           //For loop to read the text file

    int startNode = scan.nextInt();
    graph.shortestPath(startNode);                            //To show the shortest path
    scan.close();

  } catch (FileNotFoundException e) {
	  e.printStackTrace();
	  }
	 }
}