import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Lab5Q3Test {

public static void main(String[] args) {
  
  BinTreeCheckPattern tree = new BinTreeCheckPattern();
  Scanner in = new Scanner(System.in);  // Create a Scanner object
  
  System.out.println("Tree size (n): ");  //Take tree size as an input  
  int n = in.nextInt();
  
  int firstTree [] = new int[n];             //First tree node values
  System.out.println("Node values for the first tree:");  
  for (int i = 0; i < n; i ++) 
   firstTree[i] = in.nextInt();
  
  
  int secondTree [] = new int[n];            //First tree node values  
  System.out.println("Node values for the second tree:");
  for (int i = 0; i < n; i ++) 
   secondTree [i] = in.nextInt();
  
  
  for (int i = 0; i < n; i ++)              //Construct the first tree 
   tree.add(firstTree[i]);
  
  
  boolean valid = true;                    //Check if the second tree has the same parrtern     
  for (int i = 0;valid && i < n; i ++) {
   valid &= tree.checkPattern(secondTree[i]);
  }
  
  if (valid) 
    System.out.println("Both patterns generate the same binary search tree.");
  else 
    System.out.println("The patterns generate different binary search tree.");
 }
}
