
public class BinTreeCheckPattern {
 
 public TreeNodeQ3 root;        //Root node
 
 //Constructor to initialize a BST
 public BinTreeCheckPattern(){
  root = null;
 }
 
 //Add a node to the tree
 public void add(int key) {
  root = addRecursive(root, key);
 }
 
 //Recursive method to add a node to the tree
 public TreeNodeQ3 addRecursive(TreeNodeQ3 node, int key){
  if (node == null)
    return new TreeNodeQ3(key);
  else if (key < node.data)
    node.left = addRecursive(node.left, key);
  else if (key > node.data)
    node.right = addRecursive(node.right, key);
  return node;
 }
 
  
 public boolean checkPattern(int item) {
  return recursiveCheckPattern(root, item);
 }
 
 public boolean recursiveCheckPattern(TreeNodeQ3 current, int key) {
  
  //Write your code here
   
 
  return true;
 }
}
