import java.awt.Color;
public class Lab5Q1Test {
  public static final int WIDTH = 1000, HEIGHT = 750;
  public static final int MIN_SIZE = 2;
  public static void main(String[] args){
    StdDraw.setCanvasSize(WIDTH,HEIGHT);
    StdDraw.show(0);
    recursiveRectangleFill(0,1,0,1);
    StdDraw.show(0);
  }
  
  public static void recursiveRectangleFill(double minX, double maxX,
                                   double minY, double maxY){

    //Write your code here
    
  }//rectangleFill
}
