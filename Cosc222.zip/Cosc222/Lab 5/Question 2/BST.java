public class BST{
  private TreeNode root; // The root of the tree.
  
  //BST constructor
  public BST() {
    root = null;
  } 
  
  //Insert an element to the tree
  public void insert(int newItem) {
    
    //Write you code here
    
  } 
  
  
  //Display tree nodes by traversing inorder
  public void printTree()
  {
    if(root == null)
      System.out.println( "Empty tree." );
    else
    {
      inorderPrint(root);
      System.out.println();
    }
  }
  
  public void inorderPrint(TreeNode current) {
      if (current != null) {
        inorderPrint(current.left);
        System.out.print(current.data + " ");
        inorderPrint(current.right);
        }
    }
  
  
  //Display tree nodes in a descending order
  public void printTreeDesc()  {
    
    // Call the recPrintTreeDesc properly
    
  }
  
  public void recPrintTreeDesc(TreeNode current) {
    
    //Write you code here
     
  }
  
  
  
  //Display tree leafs
  public void printLeafs(){
      recursivePrintLeafs(root);
      System.out.println();
  }
    
    
  public void recursivePrintLeafs(TreeNode node) { 
     
  //Write you code here   

  }
    
    
  //Display internal nodes
  public void printInternalNodes(){
    recursiveInternalNodes(root);
    System.out.println();
  }
  
  public void recursiveInternalNodes(TreeNode node) { 
    
    //Write you code here
  }
  
  
  //Count the number of nodes in a sub-tree rooted at key 
  
  public int countNodes(int key){
    //You may want to use the search method to find the node which contains the key 
      
    //Call the recursiveCountNodes method properly
    
    return 0; // temporary, change it later
  }
  
  public int recursiveCountNodes(TreeNode node) { 
    
    //Write your code here
    
     return 0; // temporary, change it later
  }
  
  //Count the minimum node values in a sub-tree rooted at key 
  public int findSmallest(int key){
        
    //You may want to use the search method to find the node which contains the key 
    //Write your code here
   
     return 0; // temporary, change it later
  }
  
  
  //Search for a node based on a key value
  //If the key value is found in the tree, it returns the corresponding node
  //Otherwise, it returns null
  public TreeNode search(int key){
      
    //Write your code here
      
     return null; // temporary, change it later
  }
  
}