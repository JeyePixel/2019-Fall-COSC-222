import java.util.*;
public class Lab5Q2Test
{
  public static void main( String[] args )
  {
    BST tBST = new BST();    //Create an empty BST
    
    int[] nodeKeys = {52, 30, 61, 11, 62, 40, 55, 10, 9, 8};   //Tree node values

    System.out.println("Tree nodes: ");                        //Add nodes to the tree
    for ( int i = 0; i < nodeKeys.length ; i++ )
    {
      System.out.print(nodeKeys[i] + " ");
      tBST.insert(nodeKeys[i]);
    }
    
    System.out.println("\n\nInorder traversal:");             //In-order traversal
    tBST.printTree();
    
    
    System.out.println( "\nTree in descending order:" );      //display tree elements in descending order 
    tBST.printTreeDesc();
    
    System.out.println( "\nLeaf nodes:" );                    //Display all the leaf nodes
    tBST.printLeafs();
    
    System.out.println( "\nInternal nodes:" );                //Display all the internal nodes 
    tBST.printInternalNodes();
    

    int rootKey = 30;
    System.out.println( "\nNumber of nodes in the subtree rooted at " + rootKey +": "   + tBST.countNodes(rootKey));     //number of nodes in the subtree rooted at rootKey
    
    System.out.println("\nSmallest node in the subtree rooted at "+ rootKey + ": "+ tBST.findSmallest(rootKey));         //the smallest node value in the subtree rooted at rootKey 
    
  }
}
