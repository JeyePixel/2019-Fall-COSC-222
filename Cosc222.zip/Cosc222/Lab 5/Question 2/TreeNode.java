public class TreeNode
  {
    public int data;       // value stored in node
    public TreeNode left;  // left child 
    public TreeNode right; // right child 

    
    // Constructor for initialization 
    public TreeNode( int newData )
    {
      data = newData;
      left = null;
      right = null;
    } 
}

