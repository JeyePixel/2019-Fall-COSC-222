package lab1;

public class Lab1_Question1_Test {

	public static void main(String[] args) {
		
		PhoneBook pb = new PhoneBook();
		
		System.out.println(pb.validateContact("<name>Big_Show</name><phone>250-899-6192</phone>"));
		System.out.println(pb.validateContact("<name>John+Doe</name><phone>250-899-7525</phone>"));
		System.out.println(pb.validateContact("<name>Big_Show</name><phone>+8801612300990</phone>"));
		System.out.println(pb.validateContact("<name>$Jane_Doe</name><phone>250 899 7525</phone>"));
		System.out.println(pb.validateContact("<name>John_Doe</name><phone>+1250 899 7525</phone>"));

	}

}
