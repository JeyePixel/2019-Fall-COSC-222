package lab1;

public class Real extends Number{
	
	//Instance Variables
	private double value;
	
	//One Argument Constructor
	public Real(double i) {
		setValue(i);
	}

	//New toString Method
	public String toString() {
		return String.format("%4.2f", getValue());
	}
	
	public Double magnitude() {
		return Math.abs(getValue());
	}
	
	//Getters and Setters
	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

}
