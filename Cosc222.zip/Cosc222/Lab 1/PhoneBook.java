package lab1;

public class PhoneBook {
	
	public String validateContact(String contact) {
		//Grab substring of name from the name tags
		int nameStart = contact.indexOf("<name>") + "<name>".length();
		int nameEnd = contact.indexOf("</name>", nameStart);
		String name = (String) contact.subSequence(nameStart, nameEnd);
		//Grab substring of phone number from phone tags
		int phoneStart = contact.indexOf("<phone>") + "<phone>".length();
		int phoneEnd = contact.indexOf("</phone>", phoneStart);
		String number = (String) contact.subSequence(phoneStart, phoneEnd);
		if (validateName(name) && validateNumber(number)) return "Valid Name, Valid Number";
		else if (validateName(name) && !validateNumber(number)) return "Invalid Number";
		else if (!validateName(name) && validateNumber(number)) return "Invalid Name";
		else return "Invalid Name, Invalid Number";
	}

	public boolean validateNumber(String number) {
		if (number == null) return false;
		//Match number with +000-111-2222
		else if (number.matches("\\+\\d{3}[-]\\d{3}[-]\\d{4}")) return true;
		//Match number with 000-111-2222
		else if (number.matches("\\d{3}[-]\\d{3}[-]\\d{4}")) return true;
		else return false;
	}

	public boolean validateName(String name) {
		if (name == null) return false;
		//Check if name starts with _
		if(name.charAt(0) == '_') return false;
		//Check if name only contains alphabet characters and _
		else if (name.matches("^[a-zA-Z_]*$")) return true;
		else return false;
	}
}
