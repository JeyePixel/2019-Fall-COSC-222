package lab1;

public class Whole extends Number {
	
	private int LabInteger;
	
	public Whole(int i) {
		setLabInteger(i);
	}

	public String toString() {
		return Integer.toString(getLabInteger());
	}

	public Double magnitude() {
		return (double)getLabInteger();
	}

	//Getters and Setters
	public int getLabInteger() {
		return LabInteger;
	}

	public void setLabInteger(int labInteger) {
		LabInteger = labInteger;
	}

}
