package lab1;

public class Line {
	
	//Instance Variables
	private Point begin = new Point(0,0);
	private Point end = new Point(0,0);
	
	//Four Argument Constructor
	public Line(int x1, int y1, int x2, int y2) {
		begin.setX(x1);
		begin.setY(y1);
		end.setX(x2);
		end.setY(y2);
	}
	
	//Two Argument Constructor
	public Line(Point p1, Point p2) {
		int x1 = p1.getX();
		int x2 = p2.getX();
		int y1 = p1.getY();
		int y2 = p2.getY();
		begin.setX(x1);
		begin.setY(y1);
		end.setX(x2);
		end.setY(y2);
	}
	
	//New toString Method
	public String toString() {
		return "Line ((" + begin.getX() + ", " + begin.getY() + "), (" + end.getX() + ", " + end.getY() + "))";
	}
	
	//Distance Method
	public Double getLength() {
		return begin.distance(end);
	}

}
