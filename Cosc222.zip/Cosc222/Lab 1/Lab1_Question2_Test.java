package lab1;

public class Lab1_Question2_Test {
    
    public static void main (String args[]) { 
       
        Point p1=new Point();
        Point p2=new Point(5, 5);
        double distance=p1.distance(p2);
        System.out.format("Distance between %s and %s is %.2f\n",p1,p2,distance);
        Line l1=new Line(p1,p2);
        System.out.format("Length of %s is %.3f\n",l1, l1.getLength());
    }
    
}

