package lab1;

public class Point {
	
	//Instance Variables
	private int x = 0;
	private int y = 0;
	
	//No Argument Constructor
	public Point() {}
	
	//2 Argument Constructor
	public Point(int x, int y) {
		setX(x);
		setY(y);
	}
	
	//Instance Argument Constructor
	public Point(Point p) {
		setX(p.getX());
		setY(p.getY());
	}

	//New toString
	public String toString() {
		return "(" + getX() + ", " + getY() + ")";
	}
	
	//Distance Method
	public double distance(Point another) {
		return Math.abs(Math.sqrt(Math.pow((another.getX() - getX()), 2) + Math.pow((another.getY() - getY()), 2)));
	}
	
	//Getters and Setters
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}

}
