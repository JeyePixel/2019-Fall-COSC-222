package lab1;

public abstract class Number {
	public abstract String toString();
	public abstract Double magnitude();
}
