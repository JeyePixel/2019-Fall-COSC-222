package lab1;

public class Complex extends Real {
	
	//Instance Variables
	private double imaginary;
	

	public Complex(double r, double c) {
		super(r);
		setImaginary(c);
	}
	
	public String toString() {
		String sign;
		if(imaginary < 0) {
			sign = "-";
		} else {
			sign = "+";
		}
		return super.toString() + sign + String.format("%4.2f", Math.abs(getImaginary())) + "i";
	}
	
	public Double magnitude() {
		return Math.sqrt(Math.pow(super.magnitude(), 2) + Math.pow(getImaginary(), 2));
	}
	
	//Getters and Setters
	public double getImaginary() {
		return imaginary;
	}

	public void setImaginary(double imaginary) {
		this.imaginary = imaginary;
	}

}
