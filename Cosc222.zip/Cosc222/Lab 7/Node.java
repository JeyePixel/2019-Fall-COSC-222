package Lab7;

/**  
 * A Node class to store items 
 * and their associated priorities.
 */    
 public class Node<T> {
   private T item;                  
   private double priority;          
   
   public Node(T item, double priority) {   
     this.item = item;
     this.priority = priority;
   }
   
   public T getItem() {
     return this.item;
   }
   
   public void setItem(T item) {
     this.item = item;;
   }
   
   public double getPriority() {
     return this.priority;
   }
   
   public void setPriority(double priority) {
     this.priority = priority;
   }
   
   @Override
   public String toString() {
     return this.item.toString() + ", " + this.priority;
   }
 }