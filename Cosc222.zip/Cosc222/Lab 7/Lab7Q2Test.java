package Lab7;

public class Lab7Q2Test {

	 public static void main(String[] args) {
	  ArrayHeap<String> heap = new ArrayHeap<String>();
	  heap.insert("c", 2);
	  heap.insert("i", 6);
	  heap.insert("g", 5);
	  heap.insert("d", 9);
	  heap.insert("a", 8);
	  heap.insert("h", 7);
	  heap.insert("e", 43);
	  heap.insert("b", 10);
	  System.out.print("Initital Min-Heap");
	  System.out.println(heap);
	  heap.removeMin();
	  System.out.print("After removing minimum");
	  System.out.println(heap);
	  System.out.print("After changing priority");
	  heap.changePriority("e", 1);
	  System.out.println(heap);
	 }
	}
