package Lab7;

public class AVLTree {

	 public TreeNode root;

	 
	 /**  
	  * Default constructor  
	  */  
	 public AVLTree() {
	  root = null;
	 }

	 /**  
	 * Method to perform right rotation  
	 */  
	 private TreeNode rightRotate(TreeNode oldParent) {
		 //First we detach the left subtree of the right child
		 TreeNode floatingNode = oldParent.getRight().getLeft();
		 //Then we make the right child the new parent
		 TreeNode newParent = oldParent.getRight();
		 //Then we make the oldParent node the left child
		 newParent.setLeft(oldParent);
		 //Then we attach floatingNode to the right of oldParent
		 oldParent.setRight(floatingNode);
		 //Update the heights to accommodate the rotation
		 oldParent.height = height(oldParent);
		 newParent.height = height(newParent);
		 if(floatingNode != null) {
			 floatingNode.height = height(floatingNode);
		 }
	     return newParent;  
	 }

	 /**  
	  * Method to perform left rotation  
	  */  
	 private TreeNode leftRotate(TreeNode oldParent) {
			//First we detach the right subtree of the left child
			 TreeNode floatingNode = oldParent.getLeft().getRight();
			 //Then we make the left child the new parent
			 TreeNode newParent = oldParent.getLeft();
			 //Then we make the oldParent node the right child
			 newParent.setRight(oldParent);
			 //Then we attach floatingNode to the left of oldParent
			 oldParent.setLeft(floatingNode);
			 //Update the heights to accommodate the rotation
			 oldParent.height = height(oldParent);
			 newParent.height = height(newParent);
			 if (floatingNode != null) {
				 floatingNode.height = height(floatingNode);
			 }
			 return newParent;
	 }

	 /**  
	  * Method to calculate the height of a tree 
	  */  
	 public int height() {
	  return height(root);
	 }

	 // Recursive height
	 private int height(TreeNode node) {
		if (node == null) {
			return -1;
		}
		int left = (node.getLeft() == null) ? 0 : node.getLeft().height;
		int right = (node.getRight() == null) ? 0 : node.getRight().height;
		node.height = 1 + Math.max(left, right);
		return node.height;
		}

	 
	 /**  
	  * Method to remove a key from the tree 
	  */
	 public void remove(int key) {
	  if (root == null) {
	   System.out.println("Tree is empty.");
	   return;
	  }
	  root = removeRecursive(root, key);
	 }

	 
	// Recursive remove
	 public TreeNode removeRecursive(TreeNode node, int key) {
		 // Base case for removal
		 if (node == null) {
			 return node;
		 }
		 
		 // Traverse the left subtree
		 if (key < node.getData()) {
			 node.setLeft(removeRecursive(node.getLeft(), key));
		 }
		 
		 //Traverse the right subtree
		 if (key > node.getData()) {
			 node.setRight(removeRecursive(node.getRight(), key));
		 }
		 
		 else {
			 // 0-1 Child Node
			 if ((node.getLeft() == null) || (node.getRight() == null)) {
				 TreeNode temp = null;
				 if(temp == node.getLeft()) {
					 temp = node.getRight();
				 } else {
					 temp = node.getLeft();
				 }
				 
				 if(temp == null) {
					 temp = node;
					 node = null;
				 } else {
					 node = temp;
				 } 
			 } else {
				 //Find the inorder successor 
				 TreeNode inorder = node.getRight();    
			     while (inorder.getLeft() != null) {
			    	 inorder = inorder.getLeft();  	
			     }
			     node.setData(inorder.getData());
			     node.setRight(removeRecursive(node.right, inorder.getData()));
			 }
		 }
		 //Update the height
		 if(node == null) {
		 } else {
			 node.height = 1 + Math.max(height(node.getLeft()), height(node.getRight()));
			 
			//Check the balance factor
			 int BF = getBalance(node);

			 if (BF > 1) {
				 return rightRotate(node);
			 }
			 
			 if (BF < -1) {
				 return leftRotate(node);
			 }
		 }
		return node;
	 }
	 
	  /**  
	  * Method to add an item to the tree 
	  */
	 public void add(int key) {
	  root = addRecursive(root, key);
	 }

	 
	 // Recursive add
	 public TreeNode addRecursive(TreeNode node, int key) {
		 if (node == null) {
			 // Check if tree is empty
			 if(root == null) {
				 root = new TreeNode(key);
				 root.height = height(root);
				 return root;
			 }
			 return new TreeNode(key);
		 } else if (key < node.getData()) {
			 node.setLeft(addRecursive(node.getLeft(), key));
		 } else if (key > node.getData()) {
			 node.setRight(addRecursive(node.getRight(), key));
		 }
		 //Update the height
		 node.height = height(node);
		 
		 //Check the balance factor
		 int BF = getBalance(node);

		 if (BF > 1) {
			 return rightRotate(node);
		 }
		 
		 if (BF < -1) {
			 return leftRotate(node);
		 }
		 return node;
	 }

	 /**  
	 * Method to calculate the balance factor of node N
	 */
	 int getBalance(TreeNode N) {
	     /*  We will subtract the height of the left subtree of 
	         N from the height of the right subtree of N  */
		 return height(N.right) - height(N.left);
	 }

	 
	 
	  //------------------------------DO NOT CHANGE THE CODE BELOW------------------------------
	 
	  /**  
	  * A method to find the smallest item from the tree 
	  */
	  private TreeNode smallest(TreeNode node) {
	  if (node != null && node.left != null) {
	   return smallest(node.left);
	  }
	  return node;
	 }

	 /**  
	 * Method to show the tree 
	 */
	 @Override
	 public String toString() {

	  if (root == null)
	   return "Tree is empty";

	  return toString(root);
	 }

	 public String toString(TreeNode current) {
	  String resutls = "";

	  if (current != null) {
	   String left = toString(current.left);
	   String right = toString(current.right);
	   if (left != "") resutls += "(" + left + ")";
	   resutls += current.data;
	   if (right  != "") resutls += "(" + right  + ")";
	  }
	  return resutls;
	 }

	}