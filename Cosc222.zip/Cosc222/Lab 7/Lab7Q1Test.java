package Lab7;

import java.util.ArrayList;
import java.util.Arrays;
 
public class Lab7Q1Test {
     
    private static AVLTree generateTree() {           //Create and return AVL tree
        AVLTree tree = new AVLTree();
        ArrayList<Integer> arrayList = new ArrayList<>(Arrays.asList(20, 45, 90, 70, 10, 40, 35, 30, 99, 60, 50, 80));
        for (int item : arrayList) 
            tree.add(item);                         // Add method is called to construct the AVL tree
        return tree;
    }
     
    private static void compareResults(String expected, String found) {
        System.out.println("Expected:\t" + expected);
        System.out.println("Found:       \t" + found);
        System.out.println("Results:\t"+(expected.compareTo(found) == 0));
    }
     
    public static void main(String[] args) {
        AVLTree tree = generateTree();
        
        System.out.println("Test 1");
        tree = generateTree();
        tree.remove(45);
        compareResults("((10)20((30)35(40)))50((60)70((80)90(99)))", tree.toString());            
        
        System.out.println("Test 2");
        tree = generateTree();
        tree.remove(60);
        tree.remove(50);
        compareResults("((10)20((30)35(40)))45((70(80))90(99))", tree.toString());
    }
}
