package Lab7;

public class TreeNode {
	 protected TreeNode left;
	 protected TreeNode right;
	 protected int height;
	 protected int data;

	 public TreeNode(int data) {
	  this.data = data;
	  height = 1;
	  left = null;
	  right = null;
	 }

	 public void setData(int data) {
	  this.data = data;
	 }

	 public int getData() {
	  return data;
	 }

	 public TreeNode getLeft() {
	  return left;
	 }

	 public TreeNode getRight() {
	  return right;
	 }

	 public void setLeft(TreeNode left) {
	  this.left = left;
	 }

	 public void setRight(TreeNode right) {
	  this.right = right;
	 }

	}
