package lab2;

public class Lab2Q4Test {
	  
	  public static void main(String[] args) { 
	    
	    //Create an ItemList linked list.
	    ItemListQ4 items = new ItemListQ4();
	    
	    items.insert("Cherry",50);
	    items.insert("Grape",100);
	    items.insert("Pear",20);
	    items.insert("Banana",10);
	        
	    //Print out the list of items
	    System.out.println("Items are: "+items);
	  }
	  
	}

