package lab2;

public class NodeQ3 {
	
	//Private instance variables
	private String name;
	private int amount;
	private NodeQ3 next;
	
	//Constructor
	public NodeQ3(String n, int a, NodeQ3 nxt) {
		name = n;
		amount = a;
		next = nxt;
	}
	
	public String toString() {
		return  "(" + name + ":" + amount + ")";
	}

	//Next Node link
	public NodeQ3 getNext() {
		return next;
	}
}
