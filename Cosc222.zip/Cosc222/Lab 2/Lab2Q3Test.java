package lab2;

public class Lab2Q3Test {
	  
	  public static void main(String[] args) { 
	    
	    //Create an ItemList linked list.
	    ItemListQ3 items = new ItemListQ3();
	    
	    items.add("Cherry",50);
	    items.add("Grape",100);
	    items.add("Pear",20);
	        
	    //Print out the list of items
	    System.out.println("Items are: "+items);
	  }
	  
	}

