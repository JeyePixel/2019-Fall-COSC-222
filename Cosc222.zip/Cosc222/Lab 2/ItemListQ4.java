package lab2;

public class ItemListQ4 {
	
	//Private instance variables
	private NodeQ4 top;
	
	//Constructor
	public ItemListQ4() {
		setTop(null);
	}

	//Add to top
	public void add(String name, int amount) {
		setTop(new NodeQ4(name, amount, getTop()));
	}
	
	//Increment amount/add to top
	public void insert(String name, int amount) {
		//If Top doesn't exist yet, make new Node top
		if (getTop() == null) {
			setTop(new NodeQ4(name, amount, null));
		} else {
			//If Top exists, start iterating through list
			NodeQ4 current = getTop();
			while(current.getNext() != null) {
				//Compare names and adjust amount accordingly
				if(current.getName() == name) {
					//Add new Node amount to current Node
					int newAmount = current.getAmount() + amount;
					current.setAmount(newAmount);
					return;
				}
				current = current.getNext();
			}
			//Even if there is no Next node, check names and adjust amount accordingly
			if(current.getName() == name) {
				int newAmount = current.getAmount() + amount;
				current.setAmount(newAmount);
			}
			current.setNext(new NodeQ4(name,amount, null));
		}
		
	}
	
	public String toString() {
		String result = "";
        NodeQ4 current = getTop();
        while(current.getNext() != null){
            result += current.toString();
            if(current.getNext() != null){
                 result += " ";
            }
            current = current.getNext();
        }
        result += current.toString();
        return "[ " + result + " ]";
	}
	
	//Getters and setters
	public NodeQ4 getTop() {
		return top;
	}

	public void setTop(NodeQ4 top) {
		this.top = top;
	}

}

