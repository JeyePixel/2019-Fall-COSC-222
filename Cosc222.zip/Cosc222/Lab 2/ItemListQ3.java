package lab2;

public class ItemListQ3 {
	
	//Private instance variables
	private NodeQ3 top;
	
	//Constructor
	public ItemListQ3() {
		top = null;
	}

	//Add node to top of list
	public void add(String name, int amount) {
		NodeQ3 next = top;
		top = new NodeQ3(name, amount, next);
	}
	
	public String toString() {
		String result = "";
        NodeQ3 current = top;
        while(current.getNext() != null){
            result += current.toString();
            if(current.getNext() != null){
                 result += " ";
            }
            current = current.getNext();
        }
        result += current.toString();
        return "[ " + result + " ]";
	}

}
