package lab2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Lab2Q2{
  
  public static final String[] SUITS = {"Clubs", "Diamonds"};
  public static final String[] RANKS = {"2", "3", "4"};
  
  public static void main(String[] args) {
    Scanner keyboard = new Scanner(System.in);
    
    //Create a brand new deck
    ArrayList deck = makeDeck();
    System.out.println("The new deck is "+deck);

    //Shuffle and print it  
    shuffle(deck);
    System.out.println("The shuffled deck is "+deck);

    //Get information about number of hands to deal, and of what size
    System.out.print("How many hands should be dealt? ");
    int numHands = keyboard.nextInt();
    System.out.print("How many cards in each hand? ");
    int numCards = keyboard.nextInt();
    
    //Deal the hands and print them.
    ArrayList[] theHands = deal(deck,numHands,numCards);
    System.out.println("The hands are:");
    for(int i=0; i<numHands; i++)
      System.out.println("Hand "+i+": "+theHands[i]);
    System.out.println("The remaining deck: "+deck);
    
  }//main
  
  public static ArrayList makeDeck(){
    ArrayList newDeck = new ArrayList();
    
    for(String rank: RANKS) {
    	newDeck.add(rank + " of " +  SUITS[0]);
    	newDeck.add(rank + " of " + SUITS[1]);
    }
    
    return newDeck;
  }
  
  public static void shuffle(ArrayList deck){
    
    Object swappedCard;
    int randomIndex;
    
    for(int i = 0; i < deck.size() - 1; i++) {
    	randomIndex = ThreadLocalRandom.current().nextInt(i, deck.size());
    	swappedCard = deck.get(randomIndex);
    	deck.remove(randomIndex);
    	deck.add(i, swappedCard);
    }
    
  }
  
  public static ArrayList[ ] deal(ArrayList deck, int numHands, int numCards){
    ArrayList[] hands = new ArrayList[numHands];
    
    //Iterate through all Hands
  //  for(ArrayList a: hands) {
    	for(int i = 0; i < numHands; i++) {
    		hands[i] = new ArrayList();
    	}
    		for(int i=0; i< numHands*numCards;i++) {
    			Object next_card= deck.remove(0);
    			hands[i % numHands].add(next_card);
    		}
    		
//    		a.add(deck.get(deck.size() - 1));
//    		deck.remove(deck.size() - 1);
    //	}
//    }
    
    return hands;
  }
  
}
