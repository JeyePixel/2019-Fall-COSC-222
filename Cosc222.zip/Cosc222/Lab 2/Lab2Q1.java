package lab2;

import java.util.ArrayList;


public class Lab2Q1 {
  
  public static void main(String[] args) {
    //Create two sample array lists with some common elements
    ArrayList a1 = new ArrayList();
    ArrayList a2 = new ArrayList();
    int[] data1 = {10, 20, 30, 40, 50};
    int[] data2 = {10, 30, 50, 70, 80};
    for(int i=0; i<data1.length; i++) a1.add(data1[i]);
    for(int i=0; i<data2.length; i++) a2.add(data2[i]);
    System.out.println("a1 is "+a1);
    System.out.println("a2 is "+a2);
    
    ArrayList removed = removeDuplicates(a1,a2);    //Remove the common elements.
    System.out.println("Removed elements: "+removed);
    System.out.println("a1 is now "+a1);
    System.out.println("a2 is now "+a2);
  }//main
  
  public static ArrayList removeDuplicates(ArrayList a1, ArrayList a2) {
  ArrayList a3 = new ArrayList();
  for(Object e: a1) {
	  if(a2.contains(e)) {
		  a3.add(e);
	  }
  }
  a1.removeAll(a3);
  a2.removeAll(a3);
  return a3; //Remove, if needed
  }
}