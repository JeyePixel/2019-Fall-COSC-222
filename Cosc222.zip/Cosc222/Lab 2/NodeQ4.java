package lab2;

public class NodeQ4 {
	
	//Private instance variables
	private String name;
	private int amount;
	private NodeQ4 next;
	
	//Constructor
	public NodeQ4(String name, int amount, NodeQ4 next) {
		setName(name);
		setAmount(amount);
		setNext(next);
	}
	
	public String toString() {
		return  "(" + getName() + ":" + getAmount() + ")";
	}

	//Getters and setters
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public NodeQ4 getNext() {
		return next;
	}

	public void setNext(NodeQ4 next) {
		this.next = next;
	}

}

