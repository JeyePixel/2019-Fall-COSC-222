public class LinkedListCircularQueue<T> implements QueueADT <T> {

  
 // Creates an empty queue.
 public LinkedListCircularQueue() {
  
 }
 
 
 // Adds the specified element to the rear of the queue 
 @Override
 public void enqueue(T element) {
  
  
 }

 
 // Removes the element at the front of the queue and returns a reference to it. 
 @Override
 public T dequeue()  {
   
   
 }

 // Returns without removing the element at the front of the queue
 @Override
 public T first() {
  
   
 }

 // Returns true if the queue contains no elements
 @Override
 public boolean isEmpty() {
  
 }

 // Returns the number of elements in the queue
 @Override
 public int size() {
  
 }
 
 // Returns a string representation of the queue
 public String toString() {
  

 }
}




