public class LinkedListStack<T> implements StackADT<T> {

 
 //Initializes an empty stack.
 public LinkedListStack() {
  
   
 }
 
 // Adds the specified element to the top of the stack,
 @Override
 public void push(T element) {
  
   
 }

 // Removes the element at the top of the stack and returns a
 // reference to it.
 @Override
 public T pop() {
  
   
 }

 // Returns the top item
 @Override
 public T peek() {
   
 }

 // Returns true if the stack is empty and false otherwise
 @Override
 public boolean isEmpty() {
  
   
   
 }

 // Returns the number of elements in the stack
 @Override
 public int size() {
  
      
 }
 
 // Returns a string representation of this stack.
 @Override
 public String toString() {
  
   
 }
}
