package lab6;

import java.util.LinkedList; 
import java.util.Queue;

import classExamples.LinkedQueue; 

public class BinaryTree  {
  
  protected TreeNode root;
  
  //Default constructor
  public BinaryTree() {
    root = null;
  }  
  
  //Initializes the tree with a root 
  public BinaryTree(int rootItem) {
    root = new TreeNode(rootItem, null, null);
  }
  
  //Initializes the tree with the root, left subtree and right subtree  
  public BinaryTree(int rootItem, BinaryTree leftTree, BinaryTree rightTree) {
    root = new TreeNode(rootItem, null, null);
    attachToLeftSubtree(leftTree);
    attachToRightSubtree(rightTree);
  } 
  
  // Returns true if the tree is empty, else returns false.
  public boolean isEmpty() {
    return root == null;
  } 
  
  //Removes all nodes from the tree.
  public void makeEmpty() {
    root = null;
  }  
  
  // retruns the number of nodes in the tree. 
  public int size(){
    return sizeRecursive(root);
  }
  
  // recursive method to calcuate the number of nodes.
  public int sizeRecursive(TreeNode node) { 
	  if(node==null)  // Check if we have no more nodes to count 
		  return 0;
	  else 
		  return sizeRecursive(node.getLeft()) + 1 + sizeRecursive(node.getRight());
  }
  
  
  
  // Tree Traversal: inorder
  public void inorderTraversal(){
    inorderPrint(root);
  } 
  
  // Tree Traversal: inorder
  public void inorderPrint(TreeNode current) {
    if (current != null) {
      inorderPrint(current.getLeft());
      System.out.print(" " + current.getItem());
      inorderPrint(current.getRight());
    }
  }
  
  // Tree Traversal: Level order
  public void levelOrderTraversal(){
	  if(root == null) {
		  return;
	  }
	  
	  LinkedQueue<TreeNode> NodeQueue = new LinkedQueue<TreeNode>();
	  NodeQueue.enqueue(root);
	  while(!NodeQueue.isEmpty()) {
		  TreeNode current = NodeQueue.dequeue();
		  System.out.print(current.getItem() + " ");
		  if(current.getLeft() != null) {
			  NodeQueue.enqueue(current.getLeft());
		  }
		  if(current.getRight() != null) {
			  NodeQueue.enqueue(current.getRight());
		  }
	  }
  }
  
  //Check if a tree complete is a complete tree
  public boolean isCompleteTree() {
	  if(root == null) {  // Empty tree is complete tree
		  return true;
	  }
	  
	  boolean flag = false;  // We will keep track of non-full nodes with this
	  LinkedQueue<TreeNode> NodeQueue = new LinkedQueue<TreeNode>();
	  TreeNode current;
	  NodeQueue.enqueue(root);
	  while(!NodeQueue.isEmpty()) {
		  current = NodeQueue.dequeue();
		  if(flag == true && (current.getLeft() != null || current.getRight() != null)) {
			  return false;
		  }
		  
		  if(current.getLeft() == null && current.getRight() != null) {
			  return false;
		  }
		  
		  if(current.getLeft() != null) {
			  NodeQueue.enqueue(current.getLeft());
		  } else {
			  flag = true;
		  }
		  
		  if(current.getRight() != null) {
			  NodeQueue.enqueue(current.getRight());
		  } else {
			  flag = true;
		  }
	  }
	  return true;
  }
  
  
  //Check if a tree is a perfect tree
  public boolean isPerfectTree(){
	int perfectHeight = 2^(height() + 1) - 1;
	if(size() == perfectHeight)
		return true;
	else
		return false;
  }
  
  
  //Check if a tree is a full tree
  public boolean isFullTree(){
    return isFullTreeRecursive(root);
  }
  
  public boolean isFullTreeRecursive(TreeNode current){
	  if(current.getLeft() == null && current.getRight() == null) 
		  return true;
	  if(current.getLeft() != null && current.getRight() != null)
		  return isFullTreeRecursive(current.getLeft()) && isFullTreeRecursive(current.getRight());
	  else
		  return false;
  }
  
  
  //Check if the tree is a BST
  public boolean isBST(){
	  return isBSTRecursive(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
  }
  
   public boolean isBSTRecursive(TreeNode current, int min, int max){
	   if(current == null){
		   return true;
	   }
	   
	   if(current.getItem() < min || current.getItem() > max){
		   return false;
	   }
	   
	   return (isBSTRecursive(current.getLeft(), min, current.getItem() - 1) &&
			   isBSTRecursive(current.getRight(), current.getItem()+1, max));  
   }
  

//Returns the height of the tree
  public int height(){
    return heightSubtree(root);
  }
  
  
  
  public int heightSubtree(TreeNode current){
    if(current == null)  // Have to subtract 1: We are counting edges, not nodes
    	return -1;
    else {
    	int firstHeight = heightSubtree(current.getLeft());
    	int secondHeight = heightSubtree(current.getRight());
    	if(firstHeight >= secondHeight)  // Compare subtree heights
    		return firstHeight + 1;
    	else
    		return secondHeight + 1;
    } 
  }
  
  
  
  //Attached an item to the left branch 
  public void attachToLeft(int newItem) {
	  if(root.getLeft() == null)  // Check is left branch is null
		  root.setLeft(new TreeNode(newItem));  // Add new node to left branch
	  else  // If branch is occupied, tell user 
		  System.out.println("The left branch is already occupied");
  }  
  
  
  
  //Attached an item to the right branch
  public void attachToRight(int newItem) {
	  if(root.getRight() == null)  // Check is right branch is null
		  root.setRight(new TreeNode(newItem));  // Add new node to left branch
	  else  // If branch is occupied, tell user 
		  System.out.println("The right branch is already occupied");
  }  
  
  
  
  //Attached a sub-tree to the left branch
  public void attachToLeftSubtree(BinaryTree leftTree) {
	  if(root.getLeft() == null) {  //Check if there is a left subtree to root
		  root.setLeft(leftTree.root);  // Add new subtree to left node
	  } else
		  System.out.println("The left branch is already occupied");
  }  
  
  
  //Attached a sub-tree to the right branch
  public void attachToRightSubtree(BinaryTree rightTree) {
	  if(root.getRight() == null) {  //Check if there is a right subtree to root
		  root.setRight(rightTree.root);  // Add new subtree to right node
	  } else
		  System.out.println("The right branch is already occupied");
  }  
  
} 
